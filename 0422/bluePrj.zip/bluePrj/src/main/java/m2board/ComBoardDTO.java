package m2board;
import java.sql.Date;


public class ComBoardDTO 
{

   private String id;
   private String content;
   private Date write_date;
   private String boardnum;
   
   public String getId() 
   {
      return id;
   }
   public void setId(String id) 
   {
      this.id = id;
   }
   public String getContent() 
   {
      return content;
   }
   public void setContent(String content) 
   {
      this.content = content;
   }
   public Date getWrite_date() 
   {
      return write_date;
   }
   public void setWrite_date(Date write_date) 
   {
      this.write_date = write_date;
   }
   public String getBoardnum() 
   {
      return boardnum;
   }
   public void setBoardnum(String boardnum) 
   {
      this.boardnum = boardnum;
   }   
      
   
}