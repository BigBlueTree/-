package m2board;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import utils.PagingUtil;

@WebServlet("/m2board/list3.do")
public class ListController3 extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		//DAO 생성
		ClassDAO dao = new ClassDAO();
		
		//변수 저장
		Map<String, Object> map = new HashMap<>();
		
		//검색
		String searchType = req.getParameter("searchType");
		String searchStr = req.getParameter("searchStr");
		if(searchStr != null)
		{
			map.put("searchType", searchType);
			map.put("searchStr", searchStr);
		}
		
		HttpSession session = req.getSession();		
		String id = (String)session.getAttribute("id");
		
		
		System.out.println(id);
		
		//DB에서 게시물 정보 읽기
		List<ClassDTO> classList = dao.getListPage(map, id);
		dao.close();
		
	 
		//뷰에 최종 전달
		req.setAttribute("classList", classList);
		req.setAttribute("map", map);
		req.getRequestDispatcher("../blueproject/Board/List3.jsp").forward(req, resp);
		
	}
}
