package m2board;

import java.io.IOException;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import utils.AlertFunc;

@WebServlet("/m2board/write2.do")
public class WriteController2 extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 선택한 값을 DTO에 저장
    	int teacherId = Integer.parseInt(req.getParameter("id"));
        
    	ClassDTO dto = new ClassDTO();
        
    	HttpSession session = req.getSession();		

    	String teacherid = (String)session.getAttribute("id");
    	session.setAttribute(teacherid, teacherid);
		
    	
		
        
    	// class num이랑 class name 연동이 필요함
        dto.setClassnum(1);
        dto.setClassname(req.getParameter("classname"));
        dto.setTeacherid(teacherid);
        // DAO를 통해 DB에 내용 저장
        ClassDAO dao = new ClassDAO();
        int result = dao.insertWrite(dto, teacherid);
        dao.close();

        // 성공여부
        if (result == 1) {
        	AlertFunc.alertLocation(teacherid, teacherid, null);
        	resp.sendRedirect("../m2board/list3.do");
        } else {
            resp.sendRedirect("../m2board/write2.do");
        }
    }
}