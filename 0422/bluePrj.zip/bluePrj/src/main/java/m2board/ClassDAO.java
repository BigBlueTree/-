package m2board;

import java.util.List;
import java.util.Map;
import java.util.Vector;

import common.JDBConnPool;

public class ClassDAO extends JDBConnPool {
    public ClassDAO() {
        super();
    }

    public List<ClassDTO> getListPage(Map<String, Object> map, String id) {
        List<ClassDTO> bl = new Vector<>();
        String query = "select * from class where teacherid = ?";
        try {
            psmt = con.prepareStatement(query);
            psmt.setString(1, id);
            rs = psmt.executeQuery();
            while (rs.next()) {
                ClassDTO dto = new ClassDTO();
                dto.setClassnum(rs.getInt(1));
                dto.setClassname(rs.getString(2));
                dto.setTeacherid(rs.getString(3));
                bl.add(dto);
            }
        } catch (Exception e) {
            System.out.println("게시물 목록 읽기 중 에러");
            e.printStackTrace();
        }
        return bl;
    }

    public int insertWrite(ClassDTO dto, String id) {
        int result = 0;
        String query = "insert into class(classnum,classname,teacherid)" + " values(seq_class_num.NEXTVAL,?,  ?)";
        try {
            psmt = con.prepareStatement(query);
            psmt.setString(1, dto.getClassname());
            psmt.setString(1, id);
            result = psmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("게시물 입력 중 예외");
            e.printStackTrace();
        }
        return result;
    }

    public int updatePost(ClassDTO dto, String id) {
        int result = 0;
        try {
            String query = "update class " + "set teacherid= ?, classname=? " + "where classnum=?";
            psmt = con.prepareStatement(query);
            psmt.setString(1, id);
            psmt.setString(2, dto.getClassname());
            psmt.setInt(3, dto.getClassnum());
            result = psmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("게시물 수정 중 에러");
            e.printStackTrace();
        }
        return result;
    }
}
